const cameraFeed = document.getElementById('camera-feed');
const captureButton = document.getElementById('capture-button');
const canvas = document.getElementById('photo-canvas');
const context = canvas.getContext('2d');
const molduraSelect = document.getElementById('moldura-select');
const molduraPreview = document.getElementById('moldura-preview');
const countdownDisplay = document.getElementById('countdown');

let cameraStream = null;

const moldurasCache = {}; 
const MOLDURAS = ['wedding', 'birthday']; 

// -----------------------------------------------------------
// FUNÇÕES DE SETUP E CÂMERA
// -----------------------------------------------------------

async function startCamera() {
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
        cameraFeed.srcObject = cameraStream;
    } catch (error) {
        console.error('Erro ao acessar a câmera:', error);
        alert('Não foi possível acessar a câmera. Verifique as permissões.');
    }
}

function preloadMolduras() {
    MOLDURAS.forEach(name => {
        const img = new Image();
        img.src = `assets/molduras/${name}.png`; // Ajuste o caminho conforme necessário
        
        img.onload = () => {
            console.log(`Moldura ${name} pré-carregada.`);
        };
        img.onerror = () => {
            console.error(`Erro ao carregar a moldura: ${name}. Certifique-se de que o arquivo existe em 'assets/molduras/${name}.png'`);
        };
        moldurasCache[name] = img;
    });
}

// -----------------------------------------------------------
// FUNÇÃO DO TIMER E CAPTURA
// -----------------------------------------------------------

function captureWithTimer() {
    let count = 3;
    
    captureButton.disabled = true;
    
    countdownDisplay.style.display = 'block';

    const timerInterval = setInterval(() => {
        if (count > 0) {
            // Alterna a cor para dar um efeito de piscar (opcional)
            countdownDisplay.style.color = (count % 2 === 0) ? 'yellow' : 'white';
            countdownDisplay.textContent = count;
            count--;
        } else {
            clearInterval(timerInterval);
            countdownDisplay.style.display = 'none';
            countdownDisplay.textContent = '';
            
            // Chama a função de captura real e garante que o botão seja reativado
            try {
                capturePhoto();
            } catch (error) {
                console.error("Erro durante a captura da foto:", error);
            } finally {
                captureButton.disabled = false;
            }
        }
    }, 1000); 
}

function capturePhoto() {
    const selectedMoldura = molduraSelect.value;

    canvas.width = cameraFeed.videoWidth;
    canvas.height = cameraFeed.videoHeight;

    // 1. Desenha o frame da câmera no canvas
    context.drawImage(cameraFeed, 0, 0, canvas.width, canvas.height);

    // 2. Aplica a moldura
    if (selectedMoldura !== 'none' && moldurasCache[selectedMoldura] && moldurasCache[selectedMoldura].complete) {
        const molduraImg = moldurasCache[selectedMoldura];
        context.drawImage(molduraImg, 0, 0, canvas.width, canvas.height);
    } else if (selectedMoldura !== 'none') {
        console.warn("A moldura não estava totalmente carregada. Foto tirada sem moldura.");
    }
    
    downloadPhoto();
}

function downloadPhoto() {
    const imageURL = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = imageURL;
    link.download = 'cabine_de_fotos_com_moldura.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// -----------------------------------------------------------
// FUNÇÕES DE UX (Pré-visualização)
// -----------------------------------------------------------

function updateMolduraPreview() {
    const selectedMoldura = molduraSelect.value;
    if (selectedMoldura === 'none') {
        molduraPreview.style.backgroundImage = 'none';
    } else {
        molduraPreview.style.backgroundImage = `url('assets/molduras/${selectedMoldura}.png')`;
    }
}

// -----------------------------------------------------------
// LISTENERS E INICIALIZAÇÃO
// -----------------------------------------------------------

molduraSelect.addEventListener('change', updateMolduraPreview);

captureButton.addEventListener('click', captureWithTimer); 

preloadMolduras(); 
startCamera();